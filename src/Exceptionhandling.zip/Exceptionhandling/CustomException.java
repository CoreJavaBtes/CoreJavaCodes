package Exceptionhandling;

public class CustomException extends NullPointerException {
	
	public CustomException(String name) {
		// TODO Auto-generated constructor stub
		super(name);
		//System.out.println(name);
	}

}
