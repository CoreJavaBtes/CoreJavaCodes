package Threadss;

public class MainThread {

	public static void main(String[] args) {
		new ThreadDemo("One");
		new ThreadDemo("Two");
	}
}
